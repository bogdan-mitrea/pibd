package DAO;
import java.util.List;
import pojo.transaction;
import java.util.Date;
import pojo.clients;
import pojo.shops;
public interface transactionDao {
 public void adaugaTransaction (transaction transaction);
 public List<transaction> afiseazaTransaction();
 public void modificaTransaction (Integer idTranzactie, shops shops, clients clients, Date PurchaseDate, Float TotalSpent);
 public void stergeTransaction (transaction transaction);
}