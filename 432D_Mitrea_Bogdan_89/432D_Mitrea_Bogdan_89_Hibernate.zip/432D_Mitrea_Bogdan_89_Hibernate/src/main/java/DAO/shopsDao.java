package DAO;
import java.util.List;
import pojo.shops;
public interface shopsDao {
 public void adaugaShops (shops shops);
 public List<shops> afiseazaShops();
 public void modificaShops (int idShop, String NumeMagazin, String Localitate, String ContactEmail, String ContactPhone);
 public void stergeShop (shops shops);
}