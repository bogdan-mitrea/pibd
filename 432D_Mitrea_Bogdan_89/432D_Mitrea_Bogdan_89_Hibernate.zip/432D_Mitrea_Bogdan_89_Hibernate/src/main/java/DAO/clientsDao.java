package DAO;
import java.util.List;
import pojo.clients;
public interface clientsDao {
 public void adaugaClients (clients clients);
 public List<clients> afiseazaClients();
 public void modificaClients (int idClient, String Nume, String Prenume, String Email, String Phone);
 public void stergeClient (clients clients);
}