package DAOImpl;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import pojo.transaction;
import DAO.transactionDao;
import java.util.Date;
import pojo.clients;
import pojo.shops;


public class transactionDaoImpl implements transactionDao{
	public void adaugaTransaction(transaction transaction) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction trans = session.beginTransaction();
		session.save(transaction);
		trans.commit();
		session.close();
	}
	public List<transaction> afiseazaTransaction() {
		List<transaction> listaTransaction = new ArrayList();
		Session session = HibernateUtil.getSessionFactory().openSession();
		org.hibernate.query.Query query = session.createQuery("From transaction");
		listaTransaction = query.list();
		return listaTransaction;
	}
	public void modificaTransaction(Integer idTranzactie, shops shops, clients clients, Date PurchaseDate, Float TotalSpent) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction trans = session.beginTransaction();
		transaction detaliiTransactions;
		detaliiTransactions = (transaction) session.load(transaction.class, idTranzactie);
		detaliiTransactions.setclients(clients);
		detaliiTransactions.setshops(shops);
		detaliiTransactions.setPurchaseDate(PurchaseDate);
		detaliiTransactions.setTotalSpent(TotalSpent);
		session.update(detaliiTransactions);
		trans.commit();
		session.close();
	}
	public void stergeTransaction(transaction transaction) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction trans = session.beginTransaction();
		session.delete(transaction);
		trans.commit();
		session.close();
	}
}