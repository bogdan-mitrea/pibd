package DAOImpl;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import pojo.shops;
import DAO.shopsDao;


public class shopsDaoImpl implements shopsDao{
	public void adaugaShops(shops shops) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction trans = session.beginTransaction();
		session.save(shops);
		trans.commit();
		session.close();
	}
	public List<shops> afiseazaShops() {
		List<shops> listaShops = new ArrayList();
		Session session = HibernateUtil.getSessionFactory().openSession();
		org.hibernate.query.Query query = session.createQuery("From shops");
		listaShops = query.list();
		return listaShops;
	}
	public void modificaShops(int idShop, String NumeMagazin, String Localitate, String ContactEmail, String ContactPhone) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction trans = session.beginTransaction();
		shops detaliiShops = (shops) session.load(shops.class, idShop);
		detaliiShops.setNumeMagazin(NumeMagazin);
		detaliiShops.setLocalitate(Localitate);
		detaliiShops.setContactEmail(ContactEmail);
		detaliiShops.setContactPhone(ContactPhone);
		session.update(detaliiShops);
		trans.commit();
		session.close();
	}
	public void stergeShop(shops shops) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction trans = session.beginTransaction();
		session.delete(shops);
		trans.commit();
		session.close();
	}
}