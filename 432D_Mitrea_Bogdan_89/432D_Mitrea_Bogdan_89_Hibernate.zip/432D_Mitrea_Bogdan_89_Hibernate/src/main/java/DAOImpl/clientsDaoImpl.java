package DAOImpl;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import pojo.clients;
import DAO.clientsDao;


public class clientsDaoImpl implements clientsDao{
	public void adaugaClients(clients clients) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction trans = session.beginTransaction();
		session.save(clients);
		trans.commit();
		session.close();
	}
	public List<clients> afiseazaClients() {
		List<clients> listaClients = new ArrayList();
		Session session = HibernateUtil.getSessionFactory().openSession();
		org.hibernate.query.Query query = session.createQuery("From clients");
		listaClients = query.list();
		return listaClients;
	}
	public void modificaClients(int idClient, String Nume, String Prenume, String Email, String Phone) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction trans = session.beginTransaction();
		clients detaliiClients = (clients) session.load(clients.class, idClient);
		detaliiClients.setNume(Nume);
		detaliiClients.setPrenume(Prenume);
		detaliiClients.setEmail(Email);
		detaliiClients.setPhone(Phone);
		session.update(detaliiClients);
		trans.commit();
		session.close();
	}
	public void stergeClient(clients clients) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction trans = session.beginTransaction();
		session.delete(clients);
		trans.commit();
		session.close();
	}
}