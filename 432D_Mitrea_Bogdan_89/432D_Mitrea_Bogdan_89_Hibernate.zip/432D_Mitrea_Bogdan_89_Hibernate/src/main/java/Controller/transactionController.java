package Controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import pojo.shops;
import pojo.clients;
import pojo.transaction;
import DAOImpl.transactionDaoImpl;
import DAOImpl.HibernateUtil;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.hibernate.Session;



public class transactionController extends HttpServlet {
	transaction transaction = new transaction();
	transactionDaoImpl transactionDaoImpl = new transactionDaoImpl();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("adaugaTransaction") != null) {

			Integer idShop = java.lang.Integer.parseInt(request.getParameter("idShop"));
			Integer idClient = java.lang.Integer.parseInt(request.getParameter("idClient"));
			Session session = HibernateUtil.getSessionFactory().openSession();
			shops shops = (shops) session.get(shops.class, idShop);
			clients clients = (clients) session.get(clients.class, idClient);
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			Date PurchaseDate = null;
			try {
				PurchaseDate = df.parse(request.getParameter("PurchaseDate"));

			} catch (ParseException e) {
				e.printStackTrace();
			}
			Float TotalSpent = java.lang.Float.parseFloat(request.getParameter("TotalSpent"));
			transaction.setshops(shops);
			transaction.setclients(clients);
			transaction.setPurchaseDate(PurchaseDate);
			transaction.setTotalSpent(TotalSpent);
			transactionDaoImpl.adaugaTransaction(transaction);
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			rd.forward(request, response);
		}
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("afiseazaTransaction") != null) {
			List<transaction> listaTransaction = new ArrayList();
			listaTransaction = transactionDaoImpl.afiseazaTransaction();
			request.setAttribute("listaTransaction", listaTransaction);
			RequestDispatcher rd = request.getRequestDispatcher("tabela_transaction.jsp");
			rd.forward(request, response);
		}
		if (request.getParameter("modificaTransaction") != null) {
			Integer id1 = Integer.parseInt(request.getParameter("idTranzactie"));

			Integer idShop = java.lang.Integer.parseInt(request.getParameter("idShop"));
			Integer idClient = java.lang.Integer.parseInt(request.getParameter("idClient"));
			Session session = HibernateUtil.getSessionFactory().openSession();
			shops shops = (shops) session.get(shops.class, idShop);
			clients clients = (clients) session.get(clients.class, idClient);
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			Date PurchaseDate = null;
			try {
				PurchaseDate = df.parse(request.getParameter("PurchaseDate"));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			Float TotalSpent = java.lang.Float.parseFloat(request.getParameter("TotalSpent"));
			transactionDaoImpl.modificaTransaction(id1, shops, clients, PurchaseDate, TotalSpent);
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			rd.forward(request, response);
		}
		if (request.getParameter("stergeTransaction") != null) {
			Integer id2 = Integer.parseInt(request.getParameter("idTranzactie"));
			transaction.setidTranzactie(id2);
			transactionDaoImpl.stergeTransaction(transaction);
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			rd.forward(request, response);
		}
	}

	@Override
	public String getServletInfo() {
		return "Short description";
	}
}