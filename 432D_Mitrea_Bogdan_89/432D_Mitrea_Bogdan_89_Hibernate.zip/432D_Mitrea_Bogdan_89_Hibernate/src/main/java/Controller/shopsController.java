package Controller;
import DAO.shopsDao;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import pojo.shops;
import DAOImpl.shopsDaoImpl;


public class shopsController extends HttpServlet {
	shops shops = new shops();
	shopsDaoImpl shopsDaoImpl = new shopsDaoImpl();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("adaugaShops") != null) {
			String NumeMagazin = request.getParameter("NumeMagazin");
			String Localitate = request.getParameter("Localitate");
			String ContactEmail = request.getParameter("ContactEmail");
			String ContactPhone = request.getParameter("ContactPhone");
			shops.setNumeMagazin(NumeMagazin);
			shops.setLocalitate(Localitate);
			shops.setContactEmail(ContactEmail);
			shops.setContactPhone(ContactPhone);
			shopsDaoImpl.adaugaShops(shops);
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			rd.forward(request, response);
		}
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("afiseazaShops") != null) {
			List<shops> listaShops = new ArrayList();
			listaShops = shopsDaoImpl.afiseazaShops();
			request.setAttribute("listaShops", listaShops);
			RequestDispatcher rd = request.getRequestDispatcher("tabela_shops.jsp");
			rd.forward(request, response);
		}
		if (request.getParameter("modificaShops") != null) {
			int id1 = Integer.parseInt(request.getParameter("idShop"));
			String NumeMagazin = request.getParameter("NumeMagazin");
			String Localitate = request.getParameter("Localitate");
			String ContactEmail = request.getParameter("ContactEmail");
			String ContactPhone = request.getParameter("ContactPhone");
			shopsDaoImpl.modificaShops(id1, NumeMagazin, Localitate, ContactEmail, ContactPhone);
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			rd.forward(request, response);
		}
		if (request.getParameter("stergeShop") != null) {
			int id2 = Integer.parseInt(request.getParameter("idShop"));
			shops.setidShop(id2);
			shopsDaoImpl.stergeShop(shops);
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			rd.forward(request, response);
		}
	}


	@Override
	public String getServletInfo() {
		return "Short description";
	}
}