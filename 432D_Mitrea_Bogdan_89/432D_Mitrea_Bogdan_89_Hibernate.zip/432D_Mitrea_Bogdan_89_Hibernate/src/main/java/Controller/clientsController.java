package Controller;
import DAO.clientsDao;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import pojo.clients;
import DAOImpl.clientsDaoImpl;



public class clientsController extends HttpServlet {
	clients clients = new clients();
	clientsDaoImpl clientsDaoImpl = new clientsDaoImpl();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("adaugaClients") != null) {
			String Nume = request.getParameter("Nume");
			String Prenume = request.getParameter("Prenume");
			String Email = request.getParameter("Email");
			String Phone = request.getParameter("Phone");
			clients.setNume(Nume);
			clients.setPrenume(Prenume);
			clients.setEmail(Email);
			clients.setPhone(Phone);
			clientsDaoImpl.adaugaClients(clients);
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			rd.forward(request, response);
		}
	}
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if (request.getParameter("afiseazaClients") != null) {
			List<clients> listaClients = new ArrayList();
			listaClients = clientsDaoImpl.afiseazaClients();
			request.setAttribute("listaClients", listaClients);
			RequestDispatcher rd = request.getRequestDispatcher("tabela_clients.jsp");
			rd.forward(request, response);
		}
		if (request.getParameter("modificaClients") != null) {
			int id1 = Integer.parseInt(request.getParameter("idClient"));
			String Nume = request.getParameter("Nume");
			String Prenume = request.getParameter("Prenume");
			String Email = request.getParameter("Email");
			String Phone = request.getParameter("Phone");
			clientsDaoImpl.modificaClients(id1, Nume, Prenume, Email, Phone);
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			rd.forward(request, response);
		}
		if (request.getParameter("stergeClient") != null) {
			int id2 = Integer.parseInt(request.getParameter("idClient"));
			clients.setidClient(id2);
			clientsDaoImpl.stergeClient(clients);
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			rd.forward(request, response);
		}
	}
	@Override
	public String getServletInfo() {
		return "Short description";
	}
}