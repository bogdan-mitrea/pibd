package pojo;
import java.util.HashSet;
import java.util.Set;
public class clients implements java.io.Serializable {
 private Integer idClient;
 private String Nume;
 private String Prenume;
 private String Email;
 private String Phone;
 private Set transaction = new HashSet(0);
 public clients() {
 }
 public clients(String Nume, String Prenume, String Email, String Phone, Set transaction) {
 this.Nume = Nume;
 this.Prenume = Prenume;
 this.Email = Email;
 this.Phone = Phone;
 this.transaction = transaction;
 }
 
 public Integer getidClient() {
 return this.idClient;
 }
 
 public void setidClient(Integer idClient) {
 this.idClient = idClient;
 }
 public String getNume() {
 return this.Nume;
 }
 
 public void setNume(String Nume) {
 this.Nume = Nume;
 }
 public String getPrenume() {
 return this.Prenume;
 }
 
 public void setPrenume(String Prenume) {
 this.Prenume = Prenume;
 }
 public String getEmail() {
 return this.Email;
 }
 
 public void setEmail(String Email) {
 this.Email = Email;
 }
 public String getPhone() {
 return this.Phone;
 }
	 
 public void setPhone(String Phone) {
 this.Phone = Phone;
 }
 public Set getTransaction() {
 return this.transaction;
 }
 
 public void setTransaction(Set transaction) {
 this.transaction = transaction;
 }
}