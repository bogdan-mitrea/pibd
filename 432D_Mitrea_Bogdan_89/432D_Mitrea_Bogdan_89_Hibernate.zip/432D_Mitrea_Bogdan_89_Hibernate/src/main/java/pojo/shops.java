package pojo;
import java.util.HashSet;
import java.util.Set;
public class shops implements java.io.Serializable {
 private Integer idShop;
 private String NumeMagazin;
 private String Localitate;
 private String ContactEmail;
 private String ContactPhone;
 private Set transaction = new HashSet(0);
 public shops() {
 }
 public shops(String NumeMagazin, String Localitate, String ContactEmail, String ContactPhone, Set transaction) {
 this.NumeMagazin = NumeMagazin;
 this.Localitate = Localitate;
 this.ContactEmail = ContactEmail;
 this.ContactPhone = ContactPhone;
 this.transaction = transaction;
 }
 
 public Integer getidShop() {
 return this.idShop;
 }
 
 public void setidShop(Integer idShop) {
 this.idShop = idShop;
 }
 public String getNumeMagazin() {
 return this.NumeMagazin;
 }
 
 public void setNumeMagazin(String NumeMagazin) {
 this.NumeMagazin = NumeMagazin;
 }
 public String getLocalitate() {
 return this.Localitate;
 }
 
 public void setLocalitate(String Localitate) {
 this.Localitate = Localitate;
 }
 public String getContactEmail() {
 return this.ContactEmail;
 }
 
 public void setContactEmail(String ContactEmail) {
 this.ContactEmail = ContactEmail;
 }
 public String getContactPhone() {
 return this.ContactPhone;
 }
	 
 public void setContactPhone(String ContactPhone) {
 this.ContactPhone = ContactPhone;
 }
 public Set getTransaction() {
 return this.transaction;
 }
 
 public void setTransaction(Set transaction) {
 this.transaction = transaction;
 }
}