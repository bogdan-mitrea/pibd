package pojo;
import java.util.Date;
public class transaction implements java.io.Serializable {
 private Integer idTranzactie;
 private clients clients;
 private shops shops;
 private Date PurchaseDate;
 private Float TotalSpent;
 public transaction() {
 }
 public transaction(clients clients, shops shops, Date PurchaseDate, Float TotalSpent) {
 this.clients = clients;
 this.shops = shops;
 this.PurchaseDate = PurchaseDate;
 this.TotalSpent = TotalSpent;
 }
 
 public Integer getidTranzactie() {
 return this.idTranzactie;
 }
 
 public void setidTranzactie(Integer idTranzactie) {
 this.idTranzactie = idTranzactie;
 }
 public clients getclients() {
 return this.clients;
 }
 
 public void setclients(clients clients) {
 this.clients = clients;
 }
 public shops getshops() {
 return this.shops;
 }
 
 public void setshops(shops shops) {
 this.shops = shops;
 }
 public Date getPurchaseDate() {
 return this.PurchaseDate;
 }
 
 public void setPurchaseDate(Date PurchaseDate) {
 this.PurchaseDate = PurchaseDate;
 }
 public Float getTotalSpent() {
 return this.TotalSpent;
 }
 
 public void setTotalSpent(Float TotalSpent) {
 this.TotalSpent = TotalSpent;
 }
}